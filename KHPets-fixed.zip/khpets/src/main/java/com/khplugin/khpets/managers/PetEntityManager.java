package com.khplugin.khpets.managers;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.model.PetData;
import com.khplugin.khpets.model.PetEffectData;
import com.khplugin.khpets.util.ColorUtil;
import com.khplugin.khpets.util.SkullUtil;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.EulerAngle;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PetEntityManager {

    private final KHPets plugin;
    private final Map<UUID, ArmorStand> activeStands = new HashMap<>();
    private final Map<UUID, TextDisplay> activeNameStands = new HashMap<>();
    private final Map<UUID, String> activePetOfPlayer = new HashMap<>();

    private double spinAngleDeg = 0;
    private long tickCounter = 0;

    public PetEntityManager(KHPets plugin) {
        this.plugin = plugin;
        startFollowTask();
    }

    private void startFollowTask() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            boolean rotateEnabled = plugin.getConfigManager().getConfig().getBoolean("pet-entity.rotate.enabled", true);
            double rotateSpeed = plugin.getConfigManager().getConfig().getDouble("pet-entity.rotate.speed", 4.0);
            boolean particlesEnabled = plugin.getConfigManager().getConfig().getBoolean("pet-entity.particles.enabled", true);
            int particleInterval = Math.max(1, plugin.getConfigManager().getConfig().getInt("pet-entity.particles.interval", 2));
            double particleRadius = plugin.getConfigManager().getConfig().getDouble("pet-entity.particles.radius", 0.35);
            double nameHeight = plugin.getConfigManager().getConfig().getDouble("pet-entity.name-height", 0.55);
            double distance = plugin.getConfigManager().getConfig().getDouble("pet-entity.distance", 1.7);

            // Client-side interpolation for the hologram: instead of the client snapping
            // to each new position packet immediately (which reads as jittery when the
            // body ArmorStand is already gliding smoothly), the TextDisplay is told to
            // tween from its old position to the new one over N ticks, so it renders as
            // fluid motion in lockstep with the pet instead of a stair-stepped hologram.
            int hologramInterpDuration = Math.max(0, plugin.getConfigManager().getConfig().getInt("pet-entity.hologram.interpolation-duration", 3));
            int hologramInterpDelay = Math.max(0, plugin.getConfigManager().getConfig().getInt("pet-entity.hologram.interpolation-delay", 0));

            // Flying follow: instead of snapping straight to the target spot every tick,
            // the pet glides toward it, so it always keeps pace and altitude with the
            // player - flying "level" (ស្មើ) with them - rather than teleport-jittering.
            boolean smoothFollow = plugin.getConfigManager().getConfig().getBoolean("pet-entity.follow.smooth", true);
            double followSpeed = clamp(plugin.getConfigManager().getConfig().getDouble("pet-entity.follow.speed", 1.0), 0.05, 1.0);

            boolean hoverEnabled = plugin.getConfigManager().getConfig().getBoolean("pet-entity.hover.enabled", true);
            double hoverAmplitude = plugin.getConfigManager().getConfig().getDouble("pet-entity.hover.amplitude", 0.08);
            double hoverSpeed = plugin.getConfigManager().getConfig().getDouble("pet-entity.hover.speed", 3.0);

            spinAngleDeg = (spinAngleDeg + rotateSpeed) % 360;
            tickCounter++;

            double hoverOffset = hoverEnabled ? Math.sin(Math.toRadians(tickCounter * hoverSpeed)) * hoverAmplitude : 0.0;

            for (Map.Entry<UUID, ArmorStand> entry : activeStands.entrySet()) {
                Player player = plugin.getServer().getPlayer(entry.getKey());
                ArmorStand stand = entry.getValue();
                if (player == null || !player.isOnline() || stand == null || stand.isDead()) {
                    continue;
                }

                Location eye = player.getEyeLocation();
                // Use yaw only (ignore pitch) so the pet keeps its distance in front of the
                // player even when the player looks straight up or down instead of sliding
                // up onto the player's head.
                float yaw = eye.getYaw();
                double yawRad = Math.toRadians(yaw);
                double forwardX = -Math.sin(yawRad);
                double forwardZ = Math.cos(yawRad);

                Location target = eye.clone().add(-forwardX * distance, 0.35 + hoverOffset, -forwardZ * distance);
                target.setPitch(0);
                target.setYaw(yaw);

                Location flightPos;
                if (smoothFollow) {
                    Location current = stand.getLocation();
                    double distToTarget = (current.getWorld() == target.getWorld())
                            ? current.distance(target) : Double.MAX_VALUE;
                    // If the pet is too far behind (teleport, respawn, big lag spike), snap
                    // instantly instead of slowly crawling across the map.
                    if (distToTarget == Double.MAX_VALUE || distToTarget > 8.0) {
                        flightPos = target;
                    } else {
                        // Catch-up boost: the further behind the pet falls (player sprinting,
                        // flying, elytra, boat, etc.), the faster it closes the gap, so it
                        // always keeps pace with the player instead of trailing further and
                        // further behind at a fixed crawl speed.
                        double effectiveSpeed = clamp(followSpeed + (distToTarget / 8.0) * (1.0 - followSpeed), followSpeed, 1.0);

                        double lx = current.getX() + (target.getX() - current.getX()) * effectiveSpeed;
                        double ly = current.getY() + (target.getY() - current.getY()) * effectiveSpeed;
                        double lz = current.getZ() + (target.getZ() - current.getZ()) * effectiveSpeed;
                        float lyaw = lerpAngle(current.getYaw(), yaw, (float) effectiveSpeed);
                        flightPos = new Location(target.getWorld(), lx, ly, lz, lyaw, 0f);
                    }
                } else {
                    flightPos = target;
                }

                stand.teleport(flightPos);

                if (rotateEnabled) {
                    stand.setHeadPose(new EulerAngle(0, Math.toRadians(spinAngleDeg), 0));
                }

                // Name hologram is glued to the pet body: its position is always derived
                // from the pet stand's just-applied location (single source of truth),
                // never recomputed independently, so it can never drift or lag behind.
                boolean hologram = plugin.getConfigManager().getConfig().getBoolean("pet-entity.show-hologram", true);
                if (hologram) {
                    TextDisplay nameStand = activeNameStands.get(entry.getKey());
                    if (nameStand == null || nameStand.isDead()) {
                        // Self-heal: if the hologram entity ever goes missing (killed by
                        // another plugin, unloaded chunk edge case, etc.) while the pet
                        // itself is still alive, respawn it immediately instead of leaving
                        // the pet permanently nameless.
                        String petId = activePetOfPlayer.get(entry.getKey());
                        PetData pet = petId != null ? plugin.getConfigManager().getPet(petId) : null;
                        if (pet != null) {
                            nameStand = createNameStand(player, stand.getLocation(), pet, nameHeight, hologramInterpDuration, hologramInterpDelay);
                            activeNameStands.put(entry.getKey(), nameStand);
                        }
                    } else {
                        // Re-assert the interpolation window every tick (cheap - just two ints)
                        // so a live config reload (/pet reload) takes effect immediately without
                        // needing to despawn/respawn the hologram.
                        nameStand.setInterpolationDuration(hologramInterpDuration);
                        nameStand.setInterpolationDelay(hologramInterpDelay);
                        Location namePos = stand.getLocation().clone().add(0, nameHeight, 0);
                        nameStand.teleport(namePos);
                    }
                }

                if (particlesEnabled && tickCounter % particleInterval == 0) {
                    spawnOrbitParticles(player, flightPos, spinAngleDeg, particleRadius);
                }
            }
        }, 1L, 1L);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    /**
     * Interpolates from {@code fromDeg} to {@code toDeg} by {@code t} (0-1), always turning
     * the short way around so the pet doesn't spin the long way when crossing 0/360.
     */
    private static float lerpAngle(float fromDeg, float toDeg, float t) {
        float delta = ((toDeg - fromDeg + 540f) % 360f) - 180f;
        return fromDeg + delta * t;
    }

    private void spawnOrbitParticles(Player player, Location center, double angleDeg, double radius) {
        String particleName = plugin.getConfigManager().getConfig().getString("pet-entity.particles.type", "ENCHANT");
        Particle particle;
        try {
            particle = Particle.valueOf(particleName.toUpperCase());
        } catch (Exception ex) {
            particle = Particle.ENCHANT;
        }
        double rad = Math.toRadians(angleDeg);
        double x1 = center.getX() + Math.cos(rad) * radius;
        double z1 = center.getZ() + Math.sin(rad) * radius;
        double x2 = center.getX() + Math.cos(rad + Math.PI) * radius;
        double z2 = center.getZ() + Math.sin(rad + Math.PI) * radius;

        player.getWorld().spawnParticle(particle, x1, center.getY() + 0.1, z1, 1, 0, 0, 0, 0);
        player.getWorld().spawnParticle(particle, x2, center.getY() + 0.1, z2, 1, 0, 0, 0, 0);
    }

    public void activatePet(Player player, PetData pet) {
        if (plugin.getLicenseManager().isEnabled() && plugin.getLicenseManager().isBlocked()) {
            player.sendMessage(org.bukkit.ChatColor.RED
                    + "Pets are temporarily disabled on this server. Please contact an admin.");
            return;
        }

        deactivatePet(player, false);

        boolean entityEnabled = plugin.getConfigManager().getConfig().getBoolean("pet-entity.enabled", true);
        boolean hidden = plugin.getPlayerDataManager().isHidden(player.getUniqueId());

        if (entityEnabled && !hidden) {
            spawnStand(player, pet);
        }

        applyEffects(player, pet);

        plugin.getPlayerDataManager().setActive(player.getUniqueId(), pet.getId());
        activePetOfPlayer.put(player.getUniqueId(), pet.getId());

        if (plugin.getConfigManager().getConfig().getBoolean("pet-entity.sound.enabled", true)) {
            try {
                String soundId = plugin.getConfigManager().getConfig().getString("pet-entity.sound.id", "entity_player_levelup");
                float pitch = (float) plugin.getConfigManager().getConfig().getDouble("pet-entity.sound.pitch", 1.3);
                Sound sound = Sound.valueOf(soundId.toUpperCase());
                player.playSound(player.getLocation(), sound, 1f, pitch);
            } catch (Exception ignored) {
            }
        }
    }

    private void spawnStand(Player player, PetData pet) {
        Location loc = player.getEyeLocation();
        ArmorStand stand = player.getWorld().spawn(loc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setSmall(true);
            as.setGravity(false);
            as.setInvulnerable(true);
            as.setBasePlate(false);
            as.setArms(false);
            as.setMarker(true);
            as.setPersistent(false);
            // Name is handled by a separate stand (see below) so it always renders
            // above the head texture instead of getting stuck underneath it.
            as.setCustomNameVisible(false);
        });

        EntityEquipment eq = stand.getEquipment();
        if (eq != null) {
            ItemStack head = SkullUtil.createSkull(pet.getEntityTexture());
            eq.setHelmet(head);
        }

        activeStands.put(player.getUniqueId(), stand);

        boolean hologram = plugin.getConfigManager().getConfig().getBoolean("pet-entity.show-hologram", true);
        if (hologram) {
            double nameHeight = plugin.getConfigManager().getConfig().getDouble("pet-entity.name-height", 0.55);
            int hologramInterpDuration = Math.max(0, plugin.getConfigManager().getConfig().getInt("pet-entity.hologram.interpolation-duration", 3));
            int hologramInterpDelay = Math.max(0, plugin.getConfigManager().getConfig().getInt("pet-entity.hologram.interpolation-delay", 0));
            TextDisplay nameStand = createNameStand(player, loc, pet, nameHeight, hologramInterpDuration, hologramInterpDelay);
            activeNameStands.put(player.getUniqueId(), nameStand);
        }
    }

    /**
     * Builds a fresh TextDisplay carrying only the pet's name text, positioned
     * {@code nameHeight} above {@code bodyLoc}. Used both on normal spawn and by the
     * follow-task self-heal path, so the hologram is built identically everywhere and is
     * always tied 1:1 to the pet it belongs to.
     * <p>
     * TextDisplay (unlike ArmorStand) supports real client-side interpolation: every
     * teleport() call is tweened smoothly by the client over
     * {@code interpolationDuration} ticks instead of being snapped to instantly, which is
     * what keeps the hologram flying level and in sync with the pet body instead of
     * looking stair-stepped.
     */
    private TextDisplay createNameStand(Player player, Location bodyLoc, PetData pet, double nameHeight,
                                         int interpolationDuration, int interpolationDelay) {
        Location namePos = bodyLoc.clone().add(0, nameHeight, 0);
        String nameTemplate = plugin.getConfigManager().getConfig().getString("pet-entity.name", "%namepet%");
        Component nameComponent = LegacyComponentSerializer.legacySection()
                .deserialize(ColorUtil.color(nameTemplate.replace("%namepet%", pet.getNamePets())));

        return player.getWorld().spawn(namePos, TextDisplay.class, td -> {
            td.setInvulnerable(true);
            td.setPersistent(false);
            td.setBillboard(Display.Billboard.CENTER);
            td.setBackgroundColor(org.bukkit.Color.fromARGB(0, 0, 0, 0));
            td.setShadowed(false);
            td.setSeeThrough(false);
            td.text(nameComponent);
            td.setInterpolationDelay(interpolationDelay);
            td.setInterpolationDuration(interpolationDuration);
            // Matches the follow task's own tick rate so a fresh spawn immediately
            // starts tweening rather than waiting for the first teleport to "arm" it.
            td.setTeleportDuration(interpolationDuration);
        });
    }

    private void removeStands(UUID uuid) {
        ArmorStand stand = activeStands.remove(uuid);
        if (stand != null && !stand.isDead()) {
            stand.remove();
        }
        TextDisplay nameStand = activeNameStands.remove(uuid);
        if (nameStand != null && !nameStand.isDead()) {
            nameStand.remove();
        }
    }

    private void applyEffects(Player player, PetData pet) {
        for (PetEffectData eff : pet.getEffects()) {
            int duration = eff.isInfinite() ? Integer.MAX_VALUE : eff.getTimeTicks();
            PotionEffect potionEffect = new PotionEffect(eff.getType(), duration, Math.max(0, eff.getLevel() - 1), true, false, true);
            player.addPotionEffect(potionEffect);
            if (eff.isFly() && !player.getAllowFlight()) {
                player.setAllowFlight(true);
                player.setFlying(false);
            }
        }
    }

    private void removeEffects(Player player, PetData pet) {
        for (PetEffectData eff : pet.getEffects()) {
            player.removePotionEffect(eff.getType());
            if (eff.isFly()) {
                player.setAllowFlight(player.getGameMode().name().contains("CREATIVE") || player.getGameMode().name().contains("SPECTATOR"));
            }
        }
    }

    public void deactivatePet(Player player, boolean persist) {
        UUID uuid = player.getUniqueId();
        removeStands(uuid);
        String activeId = activePetOfPlayer.remove(uuid);
        if (activeId != null) {
            PetData pet = plugin.getConfigManager().getPet(activeId);
            if (pet != null) {
                removeEffects(player, pet);
            }
        }
        if (persist) {
            plugin.getPlayerDataManager().setActive(uuid, "");
        }
    }

    public void despawnOnly(Player player) {
        removeStands(player.getUniqueId());
    }

    public boolean hasActivePet(UUID uuid) {
        return activePetOfPlayer.containsKey(uuid);
    }

    public String getActivePetId(UUID uuid) {
        return activePetOfPlayer.get(uuid);
    }

    /**
     * Re-applies each online player's currently active pet (name text + head texture +
     * fly capability) from the freshly loaded PetData, without deactivating/reactivating
     * the pet. Call this after {@link ConfigManager#loadAll()} (e.g. on /pet reload) so
     * that name/texture/fly edits made in the pets/*.yml files show up instantly on pets
     * that are already active, instead of requiring the player to toggle their pet off/on.
     * (Fall damage needs no special handling here - it's checked live against the
     * current config on every fall, so a reload already applies it immediately.)
     */
    public void refreshActivePets() {
        String nameTemplate = plugin.getConfigManager().getConfig().getString("pet-entity.name", "%namepet%");

        for (Map.Entry<UUID, String> entry : activePetOfPlayer.entrySet()) {
            UUID uuid = entry.getKey();
            Player player = plugin.getServer().getPlayer(uuid);
            if (player == null || !player.isOnline()) continue;

            PetData pet = plugin.getConfigManager().getPet(entry.getValue());
            if (pet == null) continue;

            ArmorStand stand = activeStands.get(uuid);
            if (stand != null && !stand.isDead()) {
                EntityEquipment eq = stand.getEquipment();
                if (eq != null) {
                    eq.setHelmet(SkullUtil.createSkull(pet.getEntityTexture()));
                }
            }

            TextDisplay nameStand = activeNameStands.get(uuid);
            if (nameStand != null && !nameStand.isDead()) {
                String coloredName = ColorUtil.color(nameTemplate.replace("%namepet%", pet.getNamePets()));
                nameStand.text(LegacyComponentSerializer.legacySection().deserialize(coloredName));
            }

            // Instantly reflect fly changes too - a player whose pet no longer grants
            // flight is pulled out of the sky immediately, even mid-flight; a player
            // whose pet newly grants flight can fly right away without re-toggling.
            boolean flyNow = false;
            for (PetEffectData eff : pet.getEffects()) {
                if (eff.isFly()) {
                    flyNow = true;
                    break;
                }
            }
            if (flyNow) {
                if (!player.getAllowFlight()) {
                    player.setAllowFlight(true);
                }
            } else {
                boolean gamemodeFlight = player.getGameMode().name().contains("CREATIVE")
                        || player.getGameMode().name().contains("SPECTATOR");
                if (!gamemodeFlight && player.getAllowFlight()) {
                    player.setFlying(false);
                    player.setAllowFlight(false);
                }
            }
        }
    }

    public void toggleHidden(Player player) {
        UUID uuid = player.getUniqueId();
        boolean nowHidden = !plugin.getPlayerDataManager().isHidden(uuid);
        plugin.getPlayerDataManager().setHidden(uuid, nowHidden);
        if (nowHidden) {
            removeStands(uuid);
        } else {
            String activeId = activePetOfPlayer.get(uuid);
            if (activeId != null) {
                PetData pet = plugin.getConfigManager().getPet(activeId);
                if (pet != null) {
                    spawnStand(player, pet);
                }
            }
        }
    }
}

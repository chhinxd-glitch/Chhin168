package com.khplugin.khpets.managers;

import com.khplugin.khpets.KHPets;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

public class PlayerDataManager {

    private final KHPets plugin;
    private final File dataFolder;
    private final Map<UUID, Set<String>> unlockedCache = new HashMap<>();
    private final Map<UUID, String> activeCache = new HashMap<>();
    private final Map<UUID, Boolean> hiddenCache = new HashMap<>();

    public PlayerDataManager(KHPets plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }

    private File fileFor(UUID uuid) {
        return new File(dataFolder, uuid.toString() + ".yml");
    }

    public void load(UUID uuid) {
        File file = fileFor(uuid);
        Set<String> unlocked = new HashSet<>();
        String active = "";
        boolean hidden = false;
        if (file.exists()) {
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            unlocked.addAll(yml.getStringList("unlocked"));
            active = yml.getString("active", "");
            hidden = yml.getBoolean("hidden", false);
        }
        unlockedCache.put(uuid, unlocked);
        activeCache.put(uuid, active);
        hiddenCache.put(uuid, hidden);
    }

    public void unload(UUID uuid) {
        save(uuid);
        unlockedCache.remove(uuid);
        activeCache.remove(uuid);
        hiddenCache.remove(uuid);
    }

    public void save(UUID uuid) {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("unlocked", new java.util.ArrayList<>(getUnlocked(uuid)));
        yml.set("active", getActive(uuid));
        yml.set("hidden", isHidden(uuid));
        try {
            yml.save(fileFor(uuid));
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Could not save playerdata for " + uuid, ex);
        }
    }

    public Set<String> getUnlocked(UUID uuid) {
        return unlockedCache.computeIfAbsent(uuid, k -> new HashSet<>());
    }

    public boolean hasUnlocked(UUID uuid, String petId) {
        return getUnlocked(uuid).contains(petId.toLowerCase());
    }

    public void unlock(UUID uuid, String petId) {
        getUnlocked(uuid).add(petId.toLowerCase());
        save(uuid);
    }

    public String getActive(UUID uuid) {
        return activeCache.getOrDefault(uuid, "");
    }

    public void setActive(UUID uuid, String petId) {
        activeCache.put(uuid, petId == null ? "" : petId.toLowerCase());
        save(uuid);
    }

    public boolean isHidden(UUID uuid) {
        return hiddenCache.getOrDefault(uuid, false);
    }

    public void setHidden(UUID uuid, boolean hidden) {
        hiddenCache.put(uuid, hidden);
        save(uuid);
    }
}

package com.khplugin.khpets.listeners;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.model.PetData;
import com.khplugin.khpets.model.PetEffectData;
import com.khplugin.khpets.util.EggUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.EquipmentSlot;

public class PlayerListener implements Listener {

    private final KHPets plugin;

    public PlayerListener(KHPets plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getPlayerDataManager().load(player.getUniqueId());

        String activeId = plugin.getPlayerDataManager().getActive(player.getUniqueId());
        if (activeId != null && !activeId.isEmpty()) {
            PetData pet = plugin.getConfigManager().getPet(activeId);
            if (pet != null && pet.isEnabled()) {
                plugin.getPetEntityManager().activatePet(player, pet);
            } else {
                plugin.getPlayerDataManager().setActive(player.getUniqueId(), "");
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        // Only despawn the visual entity; keep the active pet + effects remembered for next login
        plugin.getPetEntityManager().despawnOnly(player);
        plugin.getPlayerDataManager().unload(player.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        String activeId = plugin.getPetEntityManager().getActivePetId(player.getUniqueId());
        if (activeId == null) return;
        PetData pet = plugin.getConfigManager().getPet(activeId);
        if (pet == null) return;

        boolean deactivateOnDeath = false;
        for (PetEffectData eff : pet.getEffects()) {
            if (eff.isDeactivateOnDeath()) {
                deactivateOnDeath = true;
                break;
            }
        }
        if (deactivateOnDeath) {
            plugin.getPetEntityManager().deactivatePet(player, true);
        }
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();

        String activeId = plugin.getPetEntityManager().getActivePetId(player.getUniqueId());
        if (activeId == null) return;
        PetData pet = plugin.getConfigManager().getPet(activeId);
        if (pet == null) return;

        for (PetEffectData eff : pet.getEffects()) {
            if (eff.isFallDamage()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) return;
        ItemStack item = event.getItem();
        if (item == null) return;
        String petId = EggUtil.getPetId(plugin, item);
        if (petId == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        // Only trigger once per physical click (ignore the off-hand duplicate call)
        switch (event.getAction()) {
            case RIGHT_CLICK_AIR:
            case RIGHT_CLICK_BLOCK:
                break;
            default:
                return;
        }

        PetData pet = plugin.getConfigManager().getPet(petId);
        if (pet == null) {
            player.sendMessage(plugin.getConfigManager().msg("pet-not-found", java.util.Map.of("%pet%", petId)));
            return;
        }

        if (plugin.getPlayerDataManager().hasUnlocked(player.getUniqueId(), petId)) {
            player.sendMessage(plugin.getConfigManager().msg("already-unlocked"));
            return;
        }

        plugin.getPlayerDataManager().unlock(player.getUniqueId(), petId);
        player.sendMessage(plugin.getConfigManager().msg("egg-unlocked", java.util.Map.of("%pet%", pet.getNamePets())));

        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
    }
}

package com.khplugin.khpets.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ColorUtil {

    // Matches hex color codes like &#FF00AA (used for RGB colors, e.g. in gradients)
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

    private ColorUtil() {
    }

    public static String color(String text) {
        if (text == null) return "";

        // Translate &#RRGGBB hex codes to real RGB colors first...
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuilder buffer = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(net.md_5.bungee.api.ChatColor.of("#" + hex).toString()));
        }
        matcher.appendTail(buffer);

        // ...then translate legacy &a &b &c... codes as before.
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    public static List<String> color(List<String> lines) {
        List<String> out = new ArrayList<>();
        if (lines == null) return out;
        for (String line : lines) {
            out.add(color(line));
        }
        return out;
    }
}

package com.khplugin.khpets.managers;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.util.ColorUtil;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/**
 * Periodically pays online players a fixed amount of money via Vault.
 * Controlled entirely by the "auto-money" section of config.yml:
 *
 * auto-money:
 *   enabled: true/false
 *   amount: 50
 *   interval-minutes: 1
 *   message: "&aYou received &f$%amount% &aautomatically!"
 */
public class AutoMoneyManager {

    private final KHPets plugin;
    private BukkitTask task;

    public AutoMoneyManager(KHPets plugin) {
        this.plugin = plugin;
    }

    /** Stops any running task, then starts a new one based on the current config (if enabled). */
    public void restart() {
        stop();

        boolean enabled = plugin.getConfigManager().getConfig().getBoolean("auto-money.enabled", false);
        if (!enabled) return;

        if (!plugin.getEconomyManager().isReady() && !plugin.getEconomyManager().setup()) {
            plugin.getLogger().warning("auto-money.enabled is true but no Vault economy plugin was found. "
                    + "Install Vault + an economy plugin (e.g. EssentialsX) for auto money to work.");
            return;
        }

        double amount = plugin.getConfigManager().getConfig().getDouble("auto-money.amount", 50);
        int intervalMinutes = Math.max(1, plugin.getConfigManager().getConfig().getInt("auto-money.interval-minutes", 1));
        long intervalTicks = intervalMinutes * 60L * 20L; // minutes -> ticks (20 ticks/sec)
        String message = plugin.getConfigManager().getConfig().getString("auto-money.message", "");

        task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                boolean success = plugin.getEconomyManager().deposit(player, amount);
                if (success && message != null && !message.isEmpty()) {
                    String amountText = amount == Math.floor(amount)
                            ? String.valueOf((long) amount)
                            : String.valueOf(amount);
                    player.sendMessage(ColorUtil.color(message.replace("%amount%", amountText)));
                }
            }
        }, intervalTicks, intervalTicks);
    }

    /** Cancels the running task, if any. Safe to call even if it's already stopped. */
    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }
}

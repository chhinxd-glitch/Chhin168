package com.khplugin.khpets.gui;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.model.PetData;
import com.khplugin.khpets.util.ColorUtil;
import com.khplugin.khpets.util.SkullUtil;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PetsGUI implements InventoryHolder {

    private final KHPets plugin;
    private final Player viewer;
    private int page;
    private Inventory inventory;
    /** slot -> pet id, only for slots inside the pet-area that hold a pet icon this render */
    private final Map<Integer, String> petSlots = new LinkedHashMap<>();
    private int prevSlot = -1;
    private int nextSlot = -1;
    private int closeSlot = -1;
    private int deactivateSlot = -1;
    private int toggleSlot = -1;
    private int petInfoSlot = -1;

    public PetsGUI(KHPets plugin, Player viewer, int page) {
        this.plugin = plugin;
        this.viewer = viewer;
        this.page = page;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void open() {
        try {
            build();
            viewer.openInventory(inventory);
        } catch (Throwable ex) {
            viewer.sendMessage(org.bukkit.ChatColor.RED + "An error occurred opening the pets menu. Ask an admin to check the console.");
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Failed to open PetsGUI for " + viewer.getName(), ex);
        }
    }

    private int slotOf(int row, int column) {
        return (row - 1) * 9 + (column - 1);
    }

    private void build() {
        ConfigurationSection gui = plugin.getConfigManager().getConfig().getConfigurationSection("gui");
        int rows = gui != null ? gui.getInt("rows", 6) : 6;
        String title = ColorUtil.color(gui != null ? gui.getString("title", "&8Pets Menu") : "&8Pets Menu");
        inventory = plugin.getServer().createInventory(this, rows * 9, title);
        petSlots.clear();

        if (gui == null) return;

        // ---- mask background ----
        ConfigurationSection mask = gui.getConfigurationSection("mask");
        if (mask != null) {
            List<String> materials = mask.getStringList("materials");
            List<String> pattern = mask.getStringList("pattern");
            for (int r = 0; r < pattern.size() && r < rows; r++) {
                String line = pattern.get(r);
                for (int c = 0; c < line.length() && c < 9; c++) {
                    char ch = line.charAt(c);
                    if (ch == '0') continue;
                    int index = Character.getNumericValue(ch) - 1;
                    if (index < 0 || index >= materials.size()) continue;
                    Material mat = Material.matchMaterial(materials.get(index).toUpperCase());
                    if (mat == null) continue;
                    ItemStack filler = new ItemStack(mat);
                    ItemMeta meta = filler.getItemMeta();
                    if (meta != null) {
                        meta.setDisplayName(" ");
                        filler.setItemMeta(meta);
                    }
                    inventory.setItem(r * 9 + c, filler);
                }
            }
        }

        // ---- pet info slot (active / no-active) ----
        ConfigurationSection petInfo = gui.getConfigurationSection("pet-info");
        if (petInfo != null) {
            petInfoSlot = slotOf(petInfo.getInt("row", 1), petInfo.getInt("column", 5));
            String activeId = plugin.getPlayerDataManager().getActive(viewer.getUniqueId());
            PetData activePet = plugin.getConfigManager().getPet(activeId);
            ItemStack infoItem;
            if (activePet != null) {
                ConfigurationSection active = petInfo.getConfigurationSection("active");
                infoItem = buildPetInfoItem(active, activePet);
            } else {
                ConfigurationSection noActive = petInfo.getConfigurationSection("no-active");
                infoItem = buildStaticHead(noActive);
            }
            inventory.setItem(petInfoSlot, infoItem);
        }

        // ---- pet area ----
        ConfigurationSection area = gui.getConfigurationSection("pet-area");
        List<PetData> unlockedPets = new ArrayList<>();
        for (PetData pet : plugin.getConfigManager().getPets().values()) {
            if (!pet.isEnabled()) continue;
            if (plugin.getPlayerDataManager().hasUnlocked(viewer.getUniqueId(), pet.getId())) {
                unlockedPets.add(pet);
            }
        }

        if (area != null) {
            int topRow = area.getInt("top-left.row", 3);
            int topCol = area.getInt("top-left.column", 2);
            int botRow = area.getInt("bottom-right.row", 5);
            int botCol = area.getInt("bottom-right.column", 8);

            List<Integer> slots = new ArrayList<>();
            for (int r = topRow; r <= botRow; r++) {
                for (int c = topCol; c <= botCol; c++) {
                    slots.add(slotOf(r, c));
                }
            }

            int perPage = slots.size();
            int start = page * perPage;
            String activeId = plugin.getPlayerDataManager().getActive(viewer.getUniqueId());

            for (int i = 0; i < slots.size(); i++) {
                int petIndex = start + i;
                if (petIndex >= unlockedPets.size()) break;
                PetData pet = unlockedPets.get(petIndex);
                boolean isActive = pet.getId().equalsIgnoreCase(activeId);
                ItemStack icon = buildPetIcon(gui.getConfigurationSection("pet-icon"), pet, isActive);
                int slot = slots.get(i);
                inventory.setItem(slot, icon);
                petSlots.put(slot, pet.getId());
            }

            boolean hasNext = unlockedPets.size() > start + perPage;
            boolean hasPrev = page > 0;

            ConfigurationSection prev = gui.getConfigurationSection("prev-page");
            if (prev != null && hasPrev) {
                prevSlot = slotOf(prev.getInt("location.row", 6), prev.getInt("location.column", 4));
                inventory.setItem(prevSlot, buildSimpleItem(prev.getString("item", "arrow"), prev.getString("name", "&fPrevious Page"), null));
            }
            ConfigurationSection next = gui.getConfigurationSection("next-page");
            if (next != null && hasNext) {
                nextSlot = slotOf(next.getInt("location.row", 6), next.getInt("location.column", 6));
                inventory.setItem(nextSlot, buildSimpleItem(next.getString("item", "arrow"), next.getString("name", "&fNext Page"), null));
            }
        }

        // ---- close ----
        ConfigurationSection close = gui.getConfigurationSection("close");
        if (close != null) {
            closeSlot = slotOf(close.getInt("location.row", 6), close.getInt("location.column", 5));
            inventory.setItem(closeSlot, buildSimpleItem(close.getString("item", "barrier"), close.getString("name", "&cClose"), null));
        }

        // ---- deactivate ----
        ConfigurationSection deactivate = gui.getConfigurationSection("deactivate-pet");
        if (deactivate != null) {
            deactivateSlot = slotOf(deactivate.getInt("location.row", 6), deactivate.getInt("location.column", 2));
            String item = deactivate.getString("item", "barrier");
            ItemStack stack = item.contains("texture:") ? SkullUtil.createSkull(item) : buildSimpleItem(item, null, null);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ColorUtil.color(deactivate.getString("name", "&cDeactivate Pet")));
                stack.setItemMeta(meta);
            }
            inventory.setItem(deactivateSlot, stack);
        }

        // ---- toggle hide/show ----
        ConfigurationSection toggle = gui.getConfigurationSection("toggle");
        if (toggle != null) {
            toggleSlot = slotOf(toggle.getInt("location.row", 6), toggle.getInt("location.column", 8));
            boolean hidden = plugin.getPlayerDataManager().isHidden(viewer.getUniqueId());
            ConfigurationSection state = toggle.getConfigurationSection(hidden ? "show-pet" : "hide-pet");
            if (state != null) {
                String item = state.getString("item", "barrier");
                ItemStack stack = item.contains("texture:") ? SkullUtil.createSkull(item) : buildSimpleItem(item, null, null);
                ItemMeta meta = stack.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(ColorUtil.color(state.getString("name", "&fToggle Pet")));
                    meta.setLore(ColorUtil.color(state.getStringList("lore")));
                    stack.setItemMeta(meta);
                }
                inventory.setItem(toggleSlot, stack);
            }
        }
    }

    private ItemStack buildStaticHead(ConfigurationSection section) {
        if (section == null) return new ItemStack(Material.PLAYER_HEAD);
        String itemStr = section.getString("item", "player_head");
        ItemStack stack = itemStr.contains("texture:") ? SkullUtil.createSkull(itemStr) : buildSimpleItem(itemStr, null, null);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.color(section.getString("name", "")));
            meta.setLore(ColorUtil.color(section.getStringList("lore")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildPetInfoItem(ConfigurationSection section, PetData pet) {
        ItemStack stack = SkullUtil.createSkull(pet.getIconTexture());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null && section != null) {
            meta.setDisplayName(ColorUtil.color(applyPlaceholders(section.getString("name", "%namepet%"), pet)));
            List<String> lore = new ArrayList<>();
            for (String line : section.getStringList("lore")) {
                lore.add(ColorUtil.color(applyPlaceholders(line, pet)));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildPetIcon(ConfigurationSection section, PetData pet, boolean active) {
        ItemStack stack = SkullUtil.createSkull(pet.getIconTexture());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null && section != null) {
            meta.setDisplayName(ColorUtil.color(applyPlaceholders(section.getString("name", "%namepet%"), pet)));
            List<String> lore = new ArrayList<>();
            for (String line : section.getStringList("lore")) {
                lore.add(ColorUtil.color(applyPlaceholders(line, pet)));
            }
            List<String> extra = active ? section.getStringList("active-lore") : section.getStringList("not-active-lore");
            for (String line : extra) {
                lore.add(ColorUtil.color(line));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String applyPlaceholders(String text, PetData pet) {
        if (text == null) return "";
        StringBuilder effects = new StringBuilder();
        pet.getEffects().forEach(e -> {
            if (effects.length() > 0) effects.append("\n");
            if (e.hasDisplayName()) {
                // Custom label from "effect_name" in the pet file, used as-is (already
                // carries its own & color codes) instead of the raw POTION_TYPE + level.
                effects.append("&7- ").append(e.getDisplayName());
            } else {
                effects.append("&7- &f").append(e.getType().getName()).append(" ").append(e.getLevel());
            }
        });
        return text.replace("%namepet%", pet.getNamePets())
                .replace("%description%", pet.getDescriptionPets())
                .replace("%effect%", effects.toString())
                .replace("%effects%", effects.toString());
    }

    private ItemStack buildSimpleItem(String materialStr, String name, List<String> lore) {
        Material mat = Material.matchMaterial(materialStr == null ? "STONE" : materialStr.toUpperCase());
        if (mat == null) mat = Material.STONE;
        ItemStack stack = new ItemStack(mat);
        if (name != null) {
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ColorUtil.color(name));
                if (lore != null) meta.setLore(ColorUtil.color(lore));
                stack.setItemMeta(meta);
            }
        }
        return stack;
    }

    public int getPage() {
        return page;
    }

    public Map<Integer, String> getPetSlots() {
        return petSlots;
    }

    public int getPrevSlot() {
        return prevSlot;
    }

    public int getNextSlot() {
        return nextSlot;
    }

    public int getCloseSlot() {
        return closeSlot;
    }

    public int getDeactivateSlot() {
        return deactivateSlot;
    }

    public int getToggleSlot() {
        return toggleSlot;
    }
}

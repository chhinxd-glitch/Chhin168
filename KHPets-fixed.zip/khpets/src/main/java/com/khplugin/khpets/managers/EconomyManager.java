package com.khplugin.khpets.managers;

import com.khplugin.khpets.KHPets;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * Thin wrapper around Vault's Economy service. Used by AutoMoneyManager to
 * hand out money on a timer. If Vault (or an economy plugin registered with
 * it) isn't installed, isReady() stays false and nothing is paid out.
 */
public class EconomyManager {

    private final KHPets plugin;
    private Economy economy;

    public EconomyManager(KHPets plugin) {
        this.plugin = plugin;
    }

    /**
     * Looks up the Vault economy provider. Safe to call multiple times
     * (e.g. on every /pet reload) in case Vault/economy loads later.
     *
     * @return true if an economy provider is now hooked
     */
    public boolean setup() {
        if (economy != null) return true;
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }

    public boolean isReady() {
        return economy != null;
    }

    /**
     * Deposits money into a player's account.
     *
     * @return true if the deposit succeeded
     */
    public boolean deposit(Player player, double amount) {
        if (economy == null) return false;
        try {
            economy.depositPlayer(player, amount);
            return true;
        } catch (Exception ex) {
            plugin.getLogger().warning("Failed to deposit money for " + player.getName() + ": " + ex.getMessage());
            return false;
        }
    }
}

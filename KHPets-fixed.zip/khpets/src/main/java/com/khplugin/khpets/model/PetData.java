package com.khplugin.khpets.model;

import java.util.List;

/**
 * Represents one pets/<id>.yml file loaded into memory.
 */
public class PetData {

    private final String id;
    private final String namePets;
    private final String descriptionPets;
    private final List<PetEffectData> effects;
    private final List<String> commands;
    private final String entityTexture;
    private final String iconTexture;
    private final boolean enabled;
    private final String eggTexture;
    private final String eggName;
    private final List<String> eggLore;

    public PetData(String id, String namePets, String descriptionPets, List<PetEffectData> effects,
                   List<String> commands, String entityTexture, String iconTexture, boolean enabled,
                   String eggTexture, String eggName, List<String> eggLore) {
        this.id = id;
        this.namePets = namePets;
        this.descriptionPets = descriptionPets;
        this.effects = effects;
        this.commands = commands;
        this.entityTexture = entityTexture;
        this.iconTexture = iconTexture;
        this.enabled = enabled;
        this.eggTexture = eggTexture;
        this.eggName = eggName;
        this.eggLore = eggLore;
    }

    public String getId() {
        return id;
    }

    public String getNamePets() {
        return namePets;
    }

    public String getDescriptionPets() {
        return descriptionPets;
    }

    public List<PetEffectData> getEffects() {
        return effects;
    }

    public List<String> getCommands() {
        return commands;
    }

    public String getEntityTexture() {
        return entityTexture;
    }

    public String getIconTexture() {
        return iconTexture;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String getEggTexture() {
        return eggTexture;
    }

    public String getEggName() {
        return eggName;
    }

    public List<String> getEggLore() {
        return eggLore;
    }
}

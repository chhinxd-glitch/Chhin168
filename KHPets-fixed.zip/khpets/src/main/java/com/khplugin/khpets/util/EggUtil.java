package com.khplugin.khpets.util;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.model.PetData;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class EggUtil {

    private EggUtil() {
    }

    public static NamespacedKey key(KHPets plugin) {
        return new NamespacedKey(plugin, "khpets_egg");
    }

    public static ItemStack createEgg(KHPets plugin, PetData pet) {
        ItemStack stack = SkullUtil.createSkull(pet.getEggTexture());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.color(pet.getEggName()));
            meta.setLore(ColorUtil.color(pet.getEggLore()));
            meta.getPersistentDataContainer().set(key(plugin), PersistentDataType.STRING, pet.getId());
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public static String getPetId(KHPets plugin, ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return null;
        if (!meta.getPersistentDataContainer().has(key(plugin), PersistentDataType.STRING)) return null;
        return meta.getPersistentDataContainer().get(key(plugin), PersistentDataType.STRING);
    }
}

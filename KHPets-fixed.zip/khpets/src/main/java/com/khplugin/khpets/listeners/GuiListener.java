package com.khplugin.khpets.listeners;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.gui.PetsGUI;
import com.khplugin.khpets.model.PetData;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class GuiListener implements Listener {

    private final KHPets plugin;

    public GuiListener(KHPets plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof PetsGUI)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        PetsGUI gui = (PetsGUI) holder;
        int slot = event.getRawSlot();

        if (slot == gui.getCloseSlot()) {
            player.closeInventory();
            return;
        }
        if (slot == gui.getDeactivateSlot()) {
            if (!plugin.getPetEntityManager().hasActivePet(player.getUniqueId())) {
                player.sendMessage(plugin.getConfigManager().msg("pet-not-active"));
                return;
            }
            plugin.getPetEntityManager().deactivatePet(player, true);
            player.sendMessage(plugin.getConfigManager().msg("pet-deactivated"));
            new PetsGUI(plugin, player, gui.getPage()).open();
            return;
        }
        if (slot == gui.getToggleSlot()) {
            plugin.getPetEntityManager().toggleHidden(player);
            new PetsGUI(plugin, player, gui.getPage()).open();
            return;
        }
        if (slot == gui.getPrevSlot()) {
            new PetsGUI(plugin, player, Math.max(0, gui.getPage() - 1)).open();
            return;
        }
        if (slot == gui.getNextSlot()) {
            new PetsGUI(plugin, player, gui.getPage() + 1).open();
            return;
        }

        String petId = gui.getPetSlots().get(slot);
        if (petId != null) {
            PetData pet = plugin.getConfigManager().getPet(petId);
            if (pet == null) return;
            String activeId = plugin.getPlayerDataManager().getActive(player.getUniqueId());
            if (petId.equalsIgnoreCase(activeId)) {
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            plugin.getPetEntityManager().activatePet(player, pet);
            player.sendMessage(plugin.getConfigManager().msg("pet-activated", java.util.Map.of("%pet%", pet.getNamePets())));
            new PetsGUI(plugin, player, gui.getPage()).open();
        }
    }
}

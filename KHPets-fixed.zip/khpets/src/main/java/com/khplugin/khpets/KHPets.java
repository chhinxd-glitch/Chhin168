package com.khplugin.khpets;

import com.khplugin.khpets.commands.PetCommand;
import com.khplugin.khpets.listeners.GuiListener;
import com.khplugin.khpets.listeners.PlayerListener;
import com.khplugin.khpets.managers.AutoMoneyManager;
import com.khplugin.khpets.managers.ConfigManager;
import com.khplugin.khpets.managers.EconomyManager;
import com.khplugin.khpets.managers.LicenseManager;
import com.khplugin.khpets.managers.PetEntityManager;
import com.khplugin.khpets.managers.PlayerDataManager;
import org.bukkit.plugin.java.JavaPlugin;

public class KHPets extends JavaPlugin {

    private static KHPets instance;

    private ConfigManager configManager;
    private PlayerDataManager playerDataManager;
    private PetEntityManager petEntityManager;
    private EconomyManager economyManager;
    private AutoMoneyManager autoMoneyManager;
    private LicenseManager licenseManager;

    @Override
    public void onEnable() {
        instance = this;

        this.configManager = new ConfigManager(this);
        this.configManager.loadAll();

        this.playerDataManager = new PlayerDataManager(this);
        this.petEntityManager = new PetEntityManager(this);
        this.economyManager = new EconomyManager(this);
        this.autoMoneyManager = new AutoMoneyManager(this);
        this.licenseManager = new LicenseManager(this);
        this.licenseManager.start();

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);

        PetCommand petCommand = new PetCommand(this);
        if (getCommand("pet") != null) {
            getCommand("pet").setExecutor(petCommand);
            getCommand("pet").setTabCompleter(petCommand);
        }

        // Load data for players already online (e.g. /reload)
        getServer().getOnlinePlayers().forEach(p -> playerDataManager.load(p.getUniqueId()));

        // Vault may not have finished loading yet on server start; scheduling this
        // one tick later gives it a chance to register its Economy service first.
        getServer().getScheduler().runTask(this, () -> {
            economyManager.setup();
            autoMoneyManager.restart();
        });

        getLogger().info("KHPets enabled - " + configManager.getPets().size() + " pet(s) loaded.");
    }

    @Override
    public void onDisable() {
        if (autoMoneyManager != null) {
            autoMoneyManager.stop();
        }
        if (petEntityManager != null) {
            getServer().getOnlinePlayers().forEach(p -> petEntityManager.despawnOnly(p));
        }
        if (playerDataManager != null) {
            getServer().getOnlinePlayers().forEach(p -> playerDataManager.save(p.getUniqueId()));
        }
    }

    public static KHPets getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public PetEntityManager getPetEntityManager() {
        return petEntityManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public AutoMoneyManager getAutoMoneyManager() {
        return autoMoneyManager;
    }

    public LicenseManager getLicenseManager() {
        return licenseManager;
    }
}

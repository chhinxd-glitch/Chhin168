package com.khplugin.khpets.model;

import org.bukkit.potion.PotionEffectType;

/**
 * Represents one "Effect:" entry from a pets/<id>.yml file.
 *
 * type       -> PotionEffectType name, e.g. NIGHT_VISION, POISON, SPEED
 * level      -> amplifier level (1 = level I)
 * timeTicks  -> duration in ticks, or -1 for infinite while pet is active
 * deactivateOnDeath -> if true, pet turns off when the owner dies and must
 *                       be re-activated from the GUI
 * fly        -> whether the pet grants flight while active. Instantly applied/removed
 *               on /pet reload for players who already have this pet active - even
 *               mid-flight, setting this to false will pull them out of the sky.
 * fallDamage -> if true, fall damage is cancelled while the pet is active (the owner
 *               is immune); if false, fall damage applies normally. Checked live on
 *               every fall, so /pet reload applies the new value immediately too.
 * displayName -> optional custom label for this effect (raw, with & color codes, not
 *               yet translated to §) coming from the pet file's top-level "effect_name"
 *               list, matched to this effect by position/index. Null or blank means
 *               "no custom name" -> callers fall back to the raw potion type name.
 */
public class PetEffectData {

    private final PotionEffectType type;
    private final int level;
    private final int timeTicks;
    private final boolean deactivateOnDeath;
    private final boolean fly;
    private final boolean fallDamage;
    private final String displayName;

    public PetEffectData(PotionEffectType type, int level, int timeTicks,
                          boolean deactivateOnDeath, boolean fly, boolean fallDamage) {
        this(type, level, timeTicks, deactivateOnDeath, fly, fallDamage, null);
    }

    public PetEffectData(PotionEffectType type, int level, int timeTicks,
                          boolean deactivateOnDeath, boolean fly, boolean fallDamage,
                          String displayName) {
        this.type = type;
        this.level = level;
        this.timeTicks = timeTicks;
        this.deactivateOnDeath = deactivateOnDeath;
        this.fly = fly;
        this.fallDamage = fallDamage;
        this.displayName = displayName;
    }

    public PotionEffectType getType() {
        return type;
    }

    public int getLevel() {
        return level;
    }

    public int getTimeTicks() {
        return timeTicks;
    }

    public boolean isInfinite() {
        return timeTicks < 0;
    }

    public boolean isDeactivateOnDeath() {
        return deactivateOnDeath;
    }

    public boolean isFly() {
        return fly;
    }

    public boolean isFallDamage() {
        return fallDamage;
    }

    /** Raw (un-colored, & codes) custom name, or null/blank if none was set for this effect. */
    public String getDisplayName() {
        return displayName;
    }

    public boolean hasDisplayName() {
        return displayName != null && !displayName.trim().isEmpty();
    }
}

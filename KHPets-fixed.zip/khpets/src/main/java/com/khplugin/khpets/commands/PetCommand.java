package com.khplugin.khpets.commands;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.gui.PetsGUI;
import com.khplugin.khpets.model.PetData;
import com.khplugin.khpets.util.EggUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PetCommand implements CommandExecutor, TabCompleter {

    private final KHPets plugin;

    public PetCommand(KHPets plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            if (args.length == 0) {
                return openGui(sender);
            }

            String sub = args[0].toLowerCase();
            switch (sub) {
                case "giveegg":
                    return handleGiveEgg(sender, args);
                case "deactivate":
                    return handleDeactivate(sender, args);
                case "reload":
                    return handleReload(sender);
                default:
                    return openGui(sender);
            }
        } catch (Throwable ex) {
            sender.sendMessage(org.bukkit.ChatColor.RED + "An error occurred running that command. Ask an admin to check the console.");
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Error handling /" + label + " " + String.join(" ", args), ex);
            return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();

        if (args.length == 1) {
            if (sender.hasPermission("khpets.command.giveegg")) options.add("giveegg");
            if (sender.hasPermission("khpets.command.deactivate")) options.add("deactivate");
            if (sender.hasPermission("khpets.admin")) options.add("reload");
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("giveegg") || sub.equals("deactivate")) {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    options.add(online.getName());
                }
            }
        } else if (args.length == 3) {
            String sub = args[0].toLowerCase();
            if (sub.equals("giveegg") || sub.equals("deactivate")) {
                options.addAll(plugin.getConfigManager().getPets().keySet());
            }
        }

        List<String> matches = new ArrayList<>();
        StringUtil.copyPartialMatches(args.length == 0 ? "" : args[args.length - 1], options, matches);
        Collections.sort(matches);
        return matches;
    }

    private boolean openGui(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(plugin.getConfigManager().rawMsg("player-only"));
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("khpets.command.pet")) {
            player.sendMessage(plugin.getConfigManager().msg("no-permission"));
            return true;
        }
        new PetsGUI(plugin, player, 0).open();
        return true;
    }

    private boolean handleGiveEgg(CommandSender sender, String[] args) {
        if (!sender.hasPermission("khpets.command.giveegg")) {
            sender.sendMessage(plugin.getConfigManager().msg("no-permission"));
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(plugin.getConfigManager().msg("usage-giveegg"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().msg("player-not-found", java.util.Map.of("%player%", args[1])));
            return true;
        }
        PetData pet = plugin.getConfigManager().getPet(args[2]);
        if (pet == null) {
            sender.sendMessage(plugin.getConfigManager().msg("pet-not-found", java.util.Map.of("%pet%", args[2])));
            return true;
        }
        ItemStack egg = EggUtil.createEgg(plugin, pet);
        target.getInventory().addItem(egg);
        target.sendMessage(plugin.getConfigManager().msg("egg-received", java.util.Map.of("%pet%", pet.getNamePets())));
        sender.sendMessage(plugin.getConfigManager().msg("egg-given", java.util.Map.of(
                "%pet%", pet.getNamePets(),
                "%player%", target.getName())));
        return true;
    }

    private boolean handleDeactivate(CommandSender sender, String[] args) {
        if (!sender.hasPermission("khpets.command.deactivate")) {
            sender.sendMessage(plugin.getConfigManager().msg("no-permission"));
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(plugin.getConfigManager().msg("usage-deactivate"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().msg("player-not-found", java.util.Map.of("%player%", args[1])));
            return true;
        }
        String petId = args[2];
        String activeId = plugin.getPetEntityManager().getActivePetId(target.getUniqueId());
        if (activeId == null || !activeId.equalsIgnoreCase(petId)) {
            sender.sendMessage(plugin.getConfigManager().msg("pet-not-active"));
            return true;
        }
        plugin.getPetEntityManager().deactivatePet(target, true);
        PetData pet = plugin.getConfigManager().getPet(petId);
        target.sendMessage(plugin.getConfigManager().msg("pet-deactivated"));
        sender.sendMessage(plugin.getConfigManager().msg("pet-deactivated-admin", java.util.Map.of(
                "%pet%", pet != null ? pet.getNamePets() : petId,
                "%player%", target.getName())));
        return true;
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("khpets.admin")) {
            sender.sendMessage(plugin.getConfigManager().msg("no-permission"));
            return true;
        }
        plugin.getConfigManager().loadAll();
        // Instantly reflect name/texture edits on pets that are already active,
        // instead of waiting for the player to toggle their pet off/on.
        plugin.getPetEntityManager().refreshActivePets();
        // Config values (enabled/amount/interval) may have changed - rebuild the task.
        plugin.getAutoMoneyManager().restart();
        // Re-check the license/block status right away instead of waiting for the timer.
        plugin.getLicenseManager().checkNow();
        sender.sendMessage(plugin.getConfigManager().msg("reload"));
        return true;
    }
}

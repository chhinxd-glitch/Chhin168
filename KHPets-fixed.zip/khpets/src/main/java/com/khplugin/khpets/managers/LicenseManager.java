package com.khplugin.khpets.managers;

import com.khplugin.khpets.KHPets;
import org.bukkit.Bukkit;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Talks to the small Node/Vercel license server (see the /license-server project next to
 * this plugin's source) so the SERVER OWNER running that dashboard can see which servers
 * have KHPets installed and remotely block/unblock them by IP.
 * <p>
 * How the block "sticks" even after the plugin is deleted and reinstalled: the block is
 * keyed by the connecting IP address on the license-server side (read straight off the
 * HTTP request, e.g. Vercel's x-forwarded-for), not by anything stored on the Minecraft
 * server. So a fresh jar on the same, still-blocked IP checks in and immediately gets
 * {@code blocked: true} again - there's no local file to delete that would "reset" it.
 * Un-blocking only happens from the dashboard (index.html) on the license server.
 * <p>
 * Fails OPEN: if the license host can't be reached (DNS hiccup, license.api-url left
 * blank, license server down), the plugin keeps whatever state it last confirmed instead
 * of punishing an admin for a transient network issue.
 */
public class LicenseManager {

    private final KHPets plugin;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    private final AtomicBoolean blocked = new AtomicBoolean(false);
    private volatile String lastMessage = "";

    public LicenseManager(KHPets plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("license.enabled", false);
    }

    public boolean isBlocked() {
        return blocked.get();
    }

    public String getLastMessage() {
        return lastMessage;
    }

    /** Call once from onEnable(). Runs an immediate check, then repeats on a timer. */
    public void start() {
        if (!isEnabled()) return;

        long intervalMinutes = Math.max(1, plugin.getConfig().getLong("license.check-interval-minutes", 10));
        long intervalTicks = intervalMinutes * 60L * 20L;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::checkNow);
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::checkNow, intervalTicks, intervalTicks);
    }

    /** Fire off one check immediately, e.g. from /pet reload, without waiting for the timer. */
    public void checkNow() {
        String base = plugin.getConfig().getString("license.api-url", "");
        if (base == null || base.trim().isEmpty()) return;
        if (!base.endsWith("/")) base = base + "/";

        try {
            String pluginId = plugin.getConfig().getString("license.plugin-id", "khpets");
            String version = plugin.getDescription().getVersion();
            String serverName = Bukkit.getServer().getName() + " " + Bukkit.getServer().getVersion();

            String body = "{\"plugin\":\"" + escape(pluginId) + "\","
                    + "\"version\":\"" + escape(version) + "\","
                    + "\"server\":\"" + escape(serverName) + "\","
                    + "\"players\":" + Bukkit.getOnlinePlayers().size() + "}";

            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(base + "api/ping"))
                    .timeout(Duration.ofSeconds(6))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            String respBody = resp.body() == null ? "" : resp.body();

            boolean nowBlocked = respBody.contains("\"blocked\":true") || respBody.contains("\"blocked\": true");
            applyState(nowBlocked, extractMessage(respBody));
        } catch (Exception ex) {
            plugin.getLogger().warning("[License] Could not reach license server (" + ex.getMessage()
                    + ") - keeping previous state.");
        }
    }

    private void applyState(boolean nowBlocked, String message) {
        this.lastMessage = message;
        boolean wasBlocked = blocked.getAndSet(nowBlocked);

        if (nowBlocked && !wasBlocked) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getLogger().severe("===================================================");
                plugin.getLogger().severe(" KHPets: this server's IP has been BLOCKED.");
                plugin.getLogger().severe(" Pets are disabled until an admin unblocks it from"
                        + " the license dashboard.");
                if (message != null && !message.isEmpty()) {
                    plugin.getLogger().severe(" Reason: " + message);
                }
                plugin.getLogger().severe("===================================================");
                // Pull every currently-active pet immediately, don't wait for the next
                // activation attempt.
                Bukkit.getOnlinePlayers().forEach(p -> plugin.getPetEntityManager().deactivatePet(p, false));
            });
        } else if (!nowBlocked && wasBlocked) {
            plugin.getLogger().info("KHPets: license check passed again - pets re-enabled.");
        }
    }

    /** Tiny hand-rolled extraction so this class doesn't need a JSON library dependency. */
    private static String extractMessage(String json) {
        int idx = json.indexOf("\"message\"");
        if (idx < 0) return "";
        int colon = json.indexOf(':', idx);
        int firstQuote = json.indexOf('"', colon + 1);
        if (colon < 0 || firstQuote < 0) return "";
        int secondQuote = json.indexOf('"', firstQuote + 1);
        while (secondQuote > 0 && json.charAt(secondQuote - 1) == '\\') {
            secondQuote = json.indexOf('"', secondQuote + 1);
        }
        if (secondQuote < 0) return "";
        return json.substring(firstQuote + 1, secondQuote);
    }

    private static String escape(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}

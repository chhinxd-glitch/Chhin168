package com.khplugin.khpets.util;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.UUID;

/**
 * Utility for creating player_head ItemStacks with a custom base64 texture
 * value (the "Head Value id" from minecraft-heads.com style sites).
 *
 * Uses Paper's official io.papermc.paper.profile.PlayerProfile API
 * (Bukkit#createProfile + SkullMeta#setPlayerProfile) instead of raw
 * NMS/authlib reflection, so it keeps working across Paper version updates.
 * Requires the server to be Paper (or a Paper fork like Purpur/Pufferfish).
 */
public final class SkullUtil {

    private SkullUtil() {
    }

    public static ItemStack createSkull(String textureValue) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (textureValue == null || textureValue.isEmpty()) {
            return head;
        }

        // Support both raw base64 values and full "player_head texture:<value>" strings
        String value = textureValue;
        int idx = value.indexOf("texture:");
        if (idx != -1) {
            value = value.substring(idx + "texture:".length()).trim();
        }
        if (value.isEmpty()) {
            return head;
        }

        try {
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta == null) {
                return head;
            }

            PlayerProfile profile = Bukkit.createProfile(UUID.randomUUID(), null);
            profile.setProperty(new ProfileProperty("textures", value));
            meta.setPlayerProfile(profile);

            head.setItemMeta(meta);
        } catch (Throwable ex) {
            // Catch Throwable (not just Exception) so any API mismatch on a given
            // server version can never crash the command/GUI that called us.
            Bukkit.getLogger().warning("[KHPets] Failed to apply custom skull texture: " + ex);
        }
        return head;
    }
}

package com.khplugin.khpets.managers;

import com.khplugin.khpets.KHPets;
import com.khplugin.khpets.model.PetData;
import com.khplugin.khpets.model.PetEffectData;
import com.khplugin.khpets.util.ColorUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class ConfigManager {

    private final KHPets plugin;
    private FileConfiguration config;
    private final Map<String, PetData> pets = new LinkedHashMap<>();

    public ConfigManager(KHPets plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.config = plugin.getConfig();

        File petsFolder = new File(plugin.getDataFolder(), "pets");
        if (!petsFolder.exists()) {
            petsFolder.mkdirs();
        }
        // Ship default example + sample pet on first run
        copyDefaultIfMissing(petsFolder, "_example.yml");
        copyDefaultIfMissing(petsFolder, "wolf.yml");

        pets.clear();
        File[] files = petsFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".yml"));
        if (files == null) return;

        for (File file : files) {
            String id = file.getName().substring(0, file.getName().length() - 4);
            if (id.equalsIgnoreCase("_example")) continue; // template only, not a real pet
            try {
                PetData data = loadPet(id, file);
                if (data != null) {
                    pets.put(id.toLowerCase(), data);
                }
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "Failed to load pet file " + file.getName(), ex);
            }
        }
        plugin.getLogger().info("Loaded " + pets.size() + " pet(s).");
    }

    private void copyDefaultIfMissing(File petsFolder, String fileName) {
        File out = new File(petsFolder, fileName);
        if (!out.exists()) {
            plugin.saveResource("pets/" + fileName, false);
        }
    }

    private PetData loadPet(String id, File file) {
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);

        String namePets = yml.getString("namepets", id);
        String description = yml.getString("descriptionpets", "");
        boolean enabled = yml.getBoolean("enabled", true);
        String entityTexture = yml.getString("entity-texture", "");
        String iconTexture = yml.getString("icon.texture", entityTexture);

        // Optional custom display names for effects, e.g.:
        //   effect_name:
        //     - "&enight vision"
        //     - "&e"
        // Matched to the "effects" list by position: effect_name[0] labels effects[0], etc.
        // A missing or blank entry just falls back to the raw potion type name, so pet
        // authors only need to name the effects they actually want to relabel.
        List<String> effectNames = yml.getStringList("effect_name");

        List<PetEffectData> effects = new ArrayList<>();
        List<Map<?, ?>> effectMaps = yml.getMapList("effects");
        for (int i = 0; i < effectMaps.size(); i++) {
            Map<?, ?> map = effectMaps.get(i);
            Object typeObj = map.get("type");
            if (typeObj == null) continue;
            PotionEffectType type = PotionEffectType.getByName(String.valueOf(typeObj).toUpperCase());
            if (type == null) {
                plugin.getLogger().warning("Unknown potion effect type '" + typeObj + "' in pet " + id);
                continue;
            }
            int level = toInt(map.get("level"), 1);
            int timeTicks = parseTime(map.get("time"));
            Object deathObj = map.get("death");
            boolean deactivateOnDeath = deathObj == null || "deactivate".equalsIgnoreCase(String.valueOf(deathObj));
            boolean fly = toBool(map.get("fly"), false);
            boolean fallDamage = toBool(map.get("falldamage"), false);
            String displayName = (i < effectNames.size()) ? effectNames.get(i) : null;
            effects.add(new PetEffectData(type, level, timeTicks, deactivateOnDeath, fly, fallDamage, displayName));
        }

        List<String> commands = yml.getStringList("commands");

        String eggTexture = yml.getString("egg.texture", iconTexture);
        String eggName = yml.getString("egg.name", namePets + " &7Egg");
        List<String> eggLore = yml.getStringList("egg.lore");

        return new PetData(id, namePets, description, effects, commands, entityTexture, iconTexture,
                enabled, eggTexture, eggName, eggLore);
    }

    private int parseTime(Object raw) {
        if (raw == null) return -1;
        String s = String.valueOf(raw).trim();
        if (s.equals("∞") || s.equalsIgnoreCase("infinite") || s.equals("-1")) {
            return -1;
        }
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    private int toInt(Object raw, int def) {
        if (raw == null) return def;
        try {
            return Integer.parseInt(String.valueOf(raw));
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private boolean toBool(Object raw, boolean def) {
        if (raw == null) return def;
        return Boolean.parseBoolean(String.valueOf(raw));
    }

    public FileConfiguration getConfig() {
        return config;
    }

    public Map<String, PetData> getPets() {
        return pets;
    }

    public PetData getPet(String id) {
        if (id == null) return null;
        return pets.get(id.toLowerCase());
    }

    public String msg(String path) {
        return msg(path, Collections.emptyMap());
    }

    /** Substitutes placeholders (e.g. "%pet%" -> "&fBaby Wolf") BEFORE coloring, so
     *  color codes inside the substituted value (like a colored pet name) render too. */
    public String msg(String path, Map<String, String> placeholders) {
        String prefix = config.getString("message.prefix", "");
        String text = prefix + config.getString("message." + path, path);
        return ColorUtil.color(applyPlaceholders(text, placeholders));
    }

    public String rawMsg(String path) {
        return rawMsg(path, Collections.emptyMap());
    }

    public String rawMsg(String path, Map<String, String> placeholders) {
        String text = config.getString("message." + path, path);
        return ColorUtil.color(applyPlaceholders(text, placeholders));
    }

    private String applyPlaceholders(String text, Map<String, String> placeholders) {
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            text = text.replace(entry.getKey(), entry.getValue());
        }
        return text;
    }
}

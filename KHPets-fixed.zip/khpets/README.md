# KHPets

Plugin Minecraft (Spigot/Paper) សម្រាប់ pets ជា player head អាច custom skin (Head Value id),
មាន GUI, effect (potion effect), និង admin commands.

## របៀប Build (JAR)

ត្រូវការ **Java 17+**, **Maven**, និង server ត្រូវជា **Paper** (ឬ fork របស់ Paper ដូចជា Purpur/Pufferfish —
មិនមែន Spigot ធម្មតាទេ ព្រោះ custom skull texture ប្រើ Paper's PlayerProfile API)។
ម៉ាស៊ីនកន្លែងសរសេរ code នេះមិនមាន internet
ដូច្នេះមិនអាច `mvn package` ឲ្យរួចនៅទីនេះទេ សូម build នៅម៉ាស៊ីនអ្នកផ្ទាល់:

```bash
cd khpets
mvn clean package
```

JAR ចេញនៅ `target/KHPets.jar` — ចម្លងទៅ `plugins/` របស់ server (Spigot/Paper 1.20.x)។

## Commands

| Command | ការប្រើ | Permission |
|---|---|---|
| `/pet`, `/pets` | បើក GUI ជ្រើសរើស/មើល pet | `khpets.command.pet` (default: true) |
| `/pet giveegg <player> <petid>` | ឲ្យ egg item សម្រាប់ unlock pet | `khpets.command.giveegg` (default: op) |
| `/pet deactivate <player> <petid>` | បិទ pet របស់ player | `khpets.command.deactivate` (default: op) |
| `/pet reload` | reload config.yml + pets/*.yml | `khpets.admin` (default: op) |

## របៀបដំណើរការ

1. Admin ប្រើ `/pet giveegg <player> <petid>` (petid = ឈ្មោះ file ក្នុង `pets/`, ឧ. `wolf`)។
2. Player ទទួល egg item ជា player head — **click ស្តាំ (right-click)** ដើម្បី unlock pet នោះ។
   Egg នឹងបាត់ ១ ភ្លាមៗពេល unlock ជោគជ័យ។
3. Player វាយ `/pet` ឬ `/pets` ដើម្បីបើក GUI ហើយ click លើ pet ណាមួយដែល unlock ហើយ
   ដើម្បីធ្វើឲ្យវា active — pet នឹងអណ្តែតលើក្បាល player ជា player head, បង្ហាញ hologram
   ឈ្មោះ pet (បើបើក `pet-entity.show-hologram: true`) និងផ្តល់ potion effect
   ដែលកំណត់ក្នុងឯកសារ pet នោះ។
4. ប្រសិនបើ effect មាន `death: deactivate` — pet នឹង deactivate ស្វ័យប្រវត្តិពេល
   player ស្លាប់ ត្រូវចូល GUI ហើយ click pet វិញដើម្បីបើកម្តងទៀត។
5. ប៊ូតុង **Deactivate** និង **Hide/Show** នៅក្នុង GUI អាចប្រើដើម្បីគ្រប់គ្រង pet ដោយផ្ទាល់។

## បង្កើត Pet ថ្មី

ចម្លង `plugins/KHPets/pets/_example.yml` ដាក់ឈ្មោះថ្មី (ឧ. `cat.yml`) — ឈ្មោះ file
(មិនរួម `.yml`) គឺជា **pet id** ប្រើក្នុង command `giveegg`/`deactivate`។ រាល់ការកែប្រែ
ត្រូវ `/pet reload` ដើម្បីអោយដំណើរការ។ បើប្តូរ `namepets` ឬ `entity-texture` ហើយ `/pet reload`,
pet ដែល active នៅលើ player ស្រាប់ (hologram name + head texture) នឹង update ភ្លាមៗ ដោយមិនចាំបាច់
deactivate/activate ឡើងវិញទេ។

```yaml
namepets: "&fMy Pet"
descriptionpets: "&7A cool pet"

effects:
  - type: SPEED          # ឈ្មោះ PotionEffectType របស់ Bukkit (SPEED, NIGHT_VISION, POISON...)
    level: 1
    time: -1              # -1 = គ្មានកំណត់ (∞) ឬដាក់ជាចំនួន ticks (20 ticks = 1 វិនាទី)
    death: deactivate      # deactivate pet ពេលស្លាប់
    fly: false
    falldamage: false    # false = គ្មាន fall damage ពេល pet active, true = ធម្មតា

# ឈ្មោះផ្ទាល់ខ្លួន (custom name) សម្រាប់បង្ហាញក្នុង GUI (%effect%/%effects%) ជំនួសពាក្យដើម
# "SPEED 1". ផ្គូផ្គងទៅ effects: ខាងលើ តាមលំដាប់ (index 0 -> index 0, ...)។ ទុកទទេ ឬលុបចោល
# បើចង់ប្រើឈ្មោះដើមវិញ។
effect_name: # custom name
  - "&enight vision"
  - "&e"

entity-texture: "<head value id>"
icon:
  texture: "<head value id>"
enabled: true
egg:
  texture: "<head value id>"
  name: "&fMy Pet Egg"
  lore:
    - "&7Right-click to unlock this pet!"
```

## Auto Money

`config.yml` មាន section `auto-money` — ចេញលុយស្វ័យប្រវត្តិឲ្យ player ដែល online គ្រប់គ្នា
រៀងរាល់ N នាទីម្តង (ត្រូវការ **Vault** + economy plugin ដូចជា EssentialsX ដំឡើងនៅលើ server):

```yaml
auto-money:
  enabled: false          # true = បើក, false = បិទ
  amount: 50               # ចំនួនលុយឲ្យម្តងៗ
  interval-minutes: 1      # ចន្លោះពេល (នាទី)
  message: "&aYou received &f$%amount% &aautomatically!"
```

ប្តូរ `enabled` ទៅ `true` រួច `/pet reload` — មិនចាំបាច់ restart server។ បើគ្មាន Vault/economy
plugin, server console នឹង warning ហើយមុខងារនេះនឹងមិនចេញលុយទេ។

## Note

- គាំទ្រទាំង color code ធម្មតា (`&a`, `&c`, `&l`...) និង **hex/RGB color** ជា `&#RRGGBB`
  (ឧ. `&#FF5733Hello`) — ប្រើបានគ្រប់ទីកន្លែងដែលមាន text (ឈ្មោះ pet, lore, message,
  ឈ្មោះ GUI button, auto-money message ។ល។)។
- Head texture value ត្រូវយកពី site ដូចជា minecraft-heads.com (ចម្លងតែ base64 value
  ដែលចាប់ផ្តើមដោយ `eyJ0ZXh0dXJlcyI6...`)។
- `config.yml` គ្រប់គ្រង GUI layout (mask, ទីតាំង button, ។ល។) ដូចដែលអ្នកកំណត់។
- Data ក្នុង `playerdata/<uuid>.yml` រក្សាទុក pet ណាដែល player unlock ហើយ + pet ណា active។
